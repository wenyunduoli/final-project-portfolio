// Set the size of the grid cells
let s = 20;

// Initialize a parameter for animation
let t = 1;

// Setup function: Initialize the canvas and no outline for shapes
function setup() {
  createCanvas(600, 600);
  noStroke();
  noiseDetail(2); // Adjust the level of detail for the Perlin noise
}

// Draw function: Create the animation
function draw() {
  // Set the background color to black at the start of each frame
  background(0);

  // Nested loops to iterate over grid points
  for (let x = -s; x < width + s; x += s) {
    for (let y = 0; y < height + s; y += s) {
      // Calculate offsets for dynamic positioning
      let n = sin(t + 30 * x) * s;
      let o = sin(t + 30 * y) * s;

      // Calculate the distance to the center of the canvas
      let m = dist(x + n, y + o, width / 2, height / 2);

      // Use Perlin noise to generate dynamic radii
      let radiusNoise = noise(x * 0.01, y * 0.01, t * 0.1);
      let circleRadius = map(radiusNoise, 0, 1, 0, s / 2);

      // Set the red color based on the radius
      let redValue = map(circleRadius, 0, s / 2, 0, 255);

      // Set the red color for both stroke and fill
      stroke(redValue, 0, 0);
      fill(redValue, 0, 0);

      // Draw a circle at the current point with the dynamic radius
      circle(x + n, y + o, 2 * circleRadius);
    }
  }

  // Increment the animation parameter for the next frame
  t += 0.04;
}
