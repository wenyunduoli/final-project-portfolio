// Set the size of the grid cells
let s = 20;

// Initialize parameters for animation and color
let t = 1;
let bgColor = 0;  // Default background color (black)
let circleColor = 255;  // Default circle color (white)

// Setup function: Initialize the canvas and no outline for shapes
function setup() {
  createCanvas(600, 600);
  noStroke();

  // Create sliders for background and circle color
  createSlider(0, 255, bgColor).input(updateBackground);
  createSlider(0, 255, circleColor).input(updateCircleColor);
}

// Draw function: Create the animation
function draw() {
  // Set the background color
  background(bgColor);

  // Nested loops to iterate over grid points
  for (let x = -s; x < width + s; x += s) {
    for (let y = 0; y < height + s; y += s) {
      // Calculate offsets for dynamic positioning
      let n = sin(t + 30 * x) * s;
      let o = sin(t + 30 * y) * s;

      // Calculate the distance to the center of the canvas
      let m = dist(x + n, y + o, width / 2, height / 2);

      // Map the distance to a smaller range
      m = map(m, 0, width / 2, 0, s / 2);

      // Set the fill color based on the circle color slider
      fill(circleColor);

      // Draw a circle at the current point with a scaled radius
      circle(x + n, y + o, 5 * m);
    }
  }

  // Increment the animation parameter for the next frame
  t += 0.04;
}

// Update background color based on slider input
function updateBackground() {
  bgColor = this.value();
}

// Update circle color based on slider input
function updateCircleColor() {
  circleColor = this.value();
}

